package com.replyai.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class ReplyRequest(
    val message: String,
    val mode: String,
    val tone: Int,
    val count: Int = 4,
    val context: String = "",
    val writingStyle: String = "طبیعی و محاوره‌ای"
)
data class ReplyResponse(val replies: List<String>)
interface ReplyApi {
    @POST("api/reply")
    suspend fun generate(@Body request: ReplyRequest): ReplyResponse
}
object ApiClient {
    val api: ReplyApi by lazy {
        Retrofit.Builder().baseUrl(BuildConfig.API_BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()).build()
            .create(ReplyApi::class.java)
    }
}
data class ReplyMode(val id: String, val title: String, val emoji: String, val subtitle: String)

private val modes = listOf(
    ReplyMode("formal", "رسمی", "🎩", "مودبانه و حرفه‌ای"),
    ReplyMode("flirty", "شوخ و جذاب", "😉", "بازیگوش و بانمک"),
    ReplyMode("partner", "پارتنر", "❤️", "گرم و محبت‌آمیز"),
    ReplyMode("friend", "رفیقانه", "🤝", "خودمانی و راحت"),
    ReplyMode("cool", "خونسرد", "😎", "کوتاه و مطمئن"),
    ReplyMode("funny", "طنز", "😂", "خلاقانه و بامزه"),
    ReplyMode("smart", "هوشمند", "✨", "تشخیص لحن مناسب"),
    ReplyMode("free", "آزاد", "📝", "هر توضیح یا شرایطی داری بنویس")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReplyAIApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReplyAIApp(context: Context) {
    var message by remember { mutableStateOf("") }
    var selectedMode by remember { mutableStateOf("smart") }
    var extraContext by remember { mutableStateOf("") }
    var writingStyle by remember { mutableStateOf("طبیعی و محاوره‌ای") }
    var tone by remember { mutableFloatStateOf(55f) }
    var replies by remember { mutableStateOf(emptyList<String>()) }
    var history by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val scheme = darkColorScheme(
        primary = Color(0xFF9B8CFF), secondary = Color(0xFF65D6C4),
        background = Color(0xFF10111A), surface = Color(0xFF1B1D2A),
        surfaceVariant = Color(0xFF292B3B)
    )

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        message = result.text
                        Toast.makeText(context, "متن تصویر استخراج شد؛ قبل از ارسال بررسی‌اش کن.", Toast.LENGTH_LONG).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(context, "استخراج متن تصویر ناموفق بود.", Toast.LENGTH_SHORT).show()
                    }
            } catch (_: Exception) {
                Toast.makeText(context, "خواندن تصویر ممکن نشد.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    MaterialTheme(colorScheme = scheme) {
        Scaffold(containerColor = scheme.background) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(15.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(15.dp), color = Color(0xFF292344)) {
                            Icon(Icons.Default.Forum, null, tint = scheme.primary,
                                modifier = Modifier.padding(12.dp).size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Reply AI", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("دستیار هوشمند جواب دادن به پیام‌ها", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("پیام دریافتی یا چیزی که می‌خوای جواب بدی", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = message, onValueChange = { message = it; error = null },
                            modifier = Modifier.fillMaxWidth(), minLines = 3,
                            placeholder = { Text("مثلاً: خیلی بامزه‌ای 😂❤️") },
                            shape = RoundedCornerShape(17.dp),
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                        )
                        OutlinedButton(onClick = { imagePicker.launch("image/*") }) {
                            Icon(Icons.Default.Image, null)
                            Spacer(Modifier.width(7.dp))
                            Text("انتخاب اسکرین‌شات و استخراج متن")
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("مود پاسخ", fontWeight = FontWeight.SemiBold)
                        modes.chunked(2).forEach { rowModes ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowModes.forEach { mode ->
                                    val selected = selectedMode == mode.id
                                    Surface(
                                        modifier = Modifier.weight(1f).clickable { selectedMode = mode.id },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (selected) Color(0xFF393052) else scheme.surface,
                                        border = BorderStroke(1.dp, if (selected) scheme.primary else Color(0xFF333546))
                                    ) {
                                        Column(Modifier.padding(11.dp)) {
                                            Text("${mode.emoji}  ${mode.title}", fontWeight = FontWeight.SemiBold)
                                            Text(mode.subtitle, color = Color.LightGray, fontSize = 10.sp)
                                        }
                                    }
                                }
                                if (rowModes.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
                if (selectedMode == "free") {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("شرایط و توضیحاتت", fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                value = extraContext, onValueChange = { extraContext = it },
                                modifier = Modifier.fillMaxWidth(), minLines = 3,
                                placeholder = { Text("مثلاً: می‌خوام جوابم بامزه باشه ولی معلوم نشه خیلی ذوق کردم...") },
                                shape = RoundedCornerShape(16.dp)
                            )
                        }
                    }
                } else {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("میزان خودمانی بودن", fontWeight = FontWeight.SemiBold)
                                Text("${tone.toInt()}٪", color = scheme.secondary)
                            }
                            Slider(value = tone, onValueChange = { tone = it }, valueRange = 0f..100f)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("محترمانه‌تر", fontSize = 11.sp, color = Color.LightGray)
                                Text("خودمانی‌تر", fontSize = 11.sp, color = Color.LightGray)
                            }
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("سبک نوشتار", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("طبیعی و محاوره‌ای", "کوتاه و مستقیم", "با جزئیات").forEach { style ->
                                FilterChip(selected = writingStyle == style, onClick = { writingStyle = style }, label = { Text(style, fontSize = 11.sp) })
                            }
                        }
                    }
                }
                item {
                    Button(
                        onClick = {
                            if (message.isBlank()) error = "اول پیام یا متن موردنظرت رو وارد کن."
                            else if (selectedMode == "free" && extraContext.isBlank()) error = "در مود آزاد، شرایط یا خواسته‌ات رو هم بنویس."
                            else {
                                loading = true; error = null; replies = emptyList()
                                scope.launch {
                                    try {
                                        val result = ApiClient.api.generate(
                                            ReplyRequest(message.trim(), selectedMode, tone.toInt(), 4,
                                                if (selectedMode == "free") extraContext.trim() else "",
                                                writingStyle)
                                        )
                                        replies = result.replies
                                        history = (listOf(message.trim() to (result.replies.firstOrNull() ?: "")) + history).take(20)
                                        if (replies.isEmpty()) error = "پاسخی دریافت نشد؛ دوباره امتحان کن."
                                    } catch (_: Exception) {
                                        error = "اتصال برقرار نشد. آدرس سرور و روشن بودن بک‌اند رو بررسی کن."
                                    } finally { loading = false }
                                }
                            }
                        },
                        enabled = !loading, modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        else { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("ساخت جواب‌های پیشنهادی") }
                    }
                    error?.let { Text(it, color = Color(0xFFFF8D8D), fontSize = 12.sp) }
                }
                if (replies.isNotEmpty()) {
                    item { Text("پیشنهادها", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
                    items(replies) { reply ->
                        Surface(color = scheme.surface, shape = RoundedCornerShape(17.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(reply, modifier = Modifier.weight(1f), lineHeight = 23.sp)
                                IconButton(onClick = {
                                    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cb.setPrimaryClip(ClipData.newPlainText("Reply AI", reply))
                                    Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
                                }) { Icon(Icons.Default.ContentCopy, "کپی", tint = scheme.secondary) }
                                IconButton(onClick = {
                                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, reply) }
                                    context.startActivity(Intent.createChooser(send, "اشتراک پاسخ"))
                                }) { Icon(Icons.Default.Share, "اشتراک‌گذاری", tint = scheme.primary) }
                            }
                        }
                    }
                }
                if (history.isNotEmpty()) {
                    item { Text("آخرین پیشنهادهای همین اجرا", fontWeight = FontWeight.Bold) }
                    items(history) { item ->
                        Surface(color = scheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                Text(item.first, color = Color.LightGray, fontSize = 11.sp, maxLines = 2)
                                Spacer(Modifier.height(5.dp))
                                Text(item.second, fontSize = 13.sp)
                            }
                        }
                    }
                }
                item {
                    Text("حریم خصوصی: تصویر فقط روی گوشی برای استخراج متن پردازش می‌شود؛ متن انتخاب‌شده برای تولید پاسخ به سرورت ارسال می‌شود. اطلاعات حساس را وارد نکن.",
                        color = Color.Gray, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}
